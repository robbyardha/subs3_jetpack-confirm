package com.ardhacodes.subs1_jetpack.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}