package com.ardhacodes.subs1_jetpack.data

data class ContentMovieTvEntity (
    var content : String
    )